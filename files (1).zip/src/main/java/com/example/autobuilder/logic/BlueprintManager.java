package com.example.autobuilder.logic;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.*;
import java.io.*;

public class BlueprintManager {
    private static final Map<String, Map<BlockPos, BlockState>> blueprints = new HashMap<>();

    public static void saveBlueprint(String name, World world, BlockPos p1, BlockPos p2) {
        Map<BlockPos, BlockState> map = new HashMap<>();
        BlockPos min = new BlockPos(
            Math.min(p1.getX(), p2.getX()),
            Math.min(p1.getY(), p2.getY()),
            Math.min(p1.getZ(), p2.getZ())
        );
        BlockPos max = new BlockPos(
            Math.max(p1.getX(), p2.getX()),
            Math.max(p1.getY(), p2.getY()),
            Math.max(p1.getZ(), p2.getZ())
        );
        for (int x = min.getX(); x <= max.getX(); x++)
            for (int y = min.getY(); y <= max.getY(); y++)
                for (int z = min.getZ(); z <= max.getZ(); z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    BlockState state = world.getBlockState(pos);
                    if (!state.isAir()) map.put(pos.subtract(min), state);
                }
        blueprints.put(name, map);
    }

    public static Set<String> listBlueprints() {
        return blueprints.keySet();
    }

    public static Map<BlockPos, BlockState> getBlueprint(String name) {
        return blueprints.get(name);
    }

    public static void deleteBlueprint(String name) {
        blueprints.remove(name);
    }

    // Xuất/nhập file JSON đơn giản (chỉ key là x,y,z và value là block id)
    public static void exportBlueprint(String name, File file) throws IOException {
        Map<BlockPos, BlockState> bp = blueprints.get(name);
        if (bp == null) return;
        BufferedWriter writer = new BufferedWriter(new FileWriter(file));
        for (Map.Entry<BlockPos, BlockState> e : bp.entrySet()) {
            BlockPos p = e.getKey();
            String b = e.getValue().getBlock().getTranslationKey();
            writer.write(p.getX() + "," + p.getY() + "," + p.getZ() + "=" + b + "\n");
        }
        writer.close();
    }
    public static void importBlueprint(String name, File file, World world) throws IOException {
        Map<BlockPos, BlockState> map = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] s = line.split("=");
            String[] xyz = s[0].split(",");
            BlockPos pos = new BlockPos(Integer.parseInt(xyz[0]), Integer.parseInt(xyz[1]), Integer.parseInt(xyz[2]));
            BlockState state = BlockState.fromId(Integer.parseInt(s[1]));
            map.put(pos, state);
        }
        reader.close();
        blueprints.put(name, map);
    }
}